package com.onlinebanking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.onlinebanking.entity.Request;
import com.onlinebanking.entity.User;
import com.onlinebanking.service.RequestService;
import com.onlinebanking.service.UserService;

import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * Project : online-banking
 * User: hendisantika
 * Email: hendisantika@gmail.com
 * Telegram : @hendisantika34
 * Date: 04/09/18
 * Time: 06.35
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/appointment")
public class RequestController {

    @Autowired
    private RequestService requestService;

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    public String createRequest(Model model) {
        Request request = new Request();
        model.addAttribute("request", request);
        model.addAttribute("dateString", "");

        return "request";
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public String createRequestPost(@ModelAttribute("appointment") Request request, @ModelAttribute("dateString") String date, Model model, Principal principal) throws ParseException {

        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd hh:mm");
        Date d1 = format1.parse(date);
        request.setDate(d1);

        User user = userService.findByUsername(principal.getName());
        request.setUser(user);

        requestService.createRequest(request);

        return "redirect:/userFront";
    }


}