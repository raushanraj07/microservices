package com.onlinebanking.service;

import java.util.List;

import com.onlinebanking.entity.Request;

/**
 * Created by IntelliJ IDEA.
 * Project : online-banking
 * User: hendisantika
 * Email: hendisantika@gmail.com
 * Telegram : @hendisantika34
 * Date: 09/08/18
 * Time: 04.33
 * To change this template use File | Settings | File Templates.
 */
public interface RequestService {

    //Request createRequest(Request request);

    List<Request> findAll();

    Request findRequest(Long id);

    void confirmRequest(Long id);

	Request createRequest(Request request);
}