package com.onlinebanking.service.UserServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebanking.entity.Request;
import com.onlinebanking.repository.RequestDao;
import com.onlinebanking.service.RequestService;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * Project : online-banking
 * User: hendisantika
 * Email: hendisantika@gmail.com
 * Telegram : @hendisantika34
 * Date: 09/08/18
 * Time: 04.38
 * To change this template use File | Settings | File Templates.
 */
@Service
public class RequestServiceImpl implements RequestService {

    @Autowired
    private RequestDao requestDao;

    public Request createRequest(Request request) {
        return requestDao.save(request);
    }

    public List<Request> findAll() {
        return requestDao.findAll();
    }

    public Request findRequest(Long id) {
        return requestDao.findById(id).get();
    }

    public void confirmRequest(Long id) {
        Request request = findRequest(id);
        request.setConfirmed(true);
        requestDao.save(request);
    }
}